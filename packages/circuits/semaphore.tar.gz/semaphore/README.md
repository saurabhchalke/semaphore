## semaphore Circuit

This circuit project contains all the necessary ingredients to upload to Sindri's API and start requesting proofs.

The circuit language is written in circom and will produce proofs that two variables x and y (public) are equal.
